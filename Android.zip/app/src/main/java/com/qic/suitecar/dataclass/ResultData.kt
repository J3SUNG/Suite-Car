package com.qic.suitecar.dataclass

data class ResultData(var result:Int)