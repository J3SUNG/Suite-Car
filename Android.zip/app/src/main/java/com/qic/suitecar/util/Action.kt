package com.qic.suitecar.util

enum class Action {
    WO,WC,AIC,AIN,AIH,AOC,AON,AOH
}