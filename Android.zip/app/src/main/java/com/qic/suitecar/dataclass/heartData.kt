package com.qic.suitecar.dataclass

data class heartData(var heart:Int,var rr_interval:Int)