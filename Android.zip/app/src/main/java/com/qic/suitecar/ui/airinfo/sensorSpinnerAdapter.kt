package com.qic.suitecar.ui.airinfo

import android.widget.ArrayAdapter

class sensorSpinnerAdapter  {

}