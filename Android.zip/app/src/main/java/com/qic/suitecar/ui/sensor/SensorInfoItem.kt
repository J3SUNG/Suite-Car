package com.qic.suitecar.ui.sensor

class SensorInfoItem (var sensor_no : Int,
                      var sname:String,
                      var mac_address:String,
                      var type:Int,
                      var status:Boolean)
