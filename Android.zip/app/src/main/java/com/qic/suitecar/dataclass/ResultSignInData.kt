package com.qic.suitecar.dataclass

data class ResultSignInData(var result:Int,var user_no:Int)