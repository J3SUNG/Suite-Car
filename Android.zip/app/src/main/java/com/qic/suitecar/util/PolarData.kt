package com.qic.suitecar.util

import com.qic.suitecar.dataclass.heartData

object PolarData {
    var heartDatas=ArrayList<heartData>()

}