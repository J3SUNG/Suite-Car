package com.qic.suitecar.dataclass

class aqiData(var type:String,var data:Float)